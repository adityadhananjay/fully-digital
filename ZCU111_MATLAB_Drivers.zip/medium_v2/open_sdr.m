node1 = sdr();
node1 = node1.zcu111_open('192.168.2.44');

%node2 = sdr();
%node2 = node2.zcu111_open('192.168.1.45');


