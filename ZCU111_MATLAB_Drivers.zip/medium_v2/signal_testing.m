tx_blob = get_tx_blob();
node1 = node1.zcu111_wr_data_blob(tx_blob);

[node1, rx_blob] = node1.zcu111_rd_data_blob();

%rx1_td = double(rx_blob(2,:)) + 1i*(double(rx_blob(1,:)));
%rx2_td = double(rx_blob(4,:)) + 1i*(double(rx_blob(3,:)));
%rx3_td = double(rx_blob(6,:)) + 1i*(double(rx_blob(5,:)));
%rx4_td = double(rx_blob(8,:)) + 1i*(double(rx_blob(7,:)));

figure(2);
clf;
plot(rx_blob(1,:)); hold on;
plot(rx_blob(2,:)); hold on;
plot(rx_blob(3,:)); hold on;
plot(rx_blob(4,:)); hold on;
plot(rx_blob(5,:)); hold on;
plot(rx_blob(6,:)); hold on;
plot(rx_blob(7,:)); hold on;
plot(rx_blob(8,:)); hold off;