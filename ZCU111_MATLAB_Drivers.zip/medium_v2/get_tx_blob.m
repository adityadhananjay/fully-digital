function blob = get_tx_blob()
    N=8192;     % FFT Size
    S=N*N*1;    % Scaling factor for time-domain

    tx1 = zeros(1,N);
    tx2 = zeros(1,N);
    tx3 = zeros(1,N);
    tx4 = zeros(1,N);

    % Choose subcarriers
    tx1(50) = 1+01;    
    tx2(60) = 1+01;
    tx3(70) = 1+01;
    tx4(80) = 1+01;

    td_tx1 = S*ifft(tx1);
    td_tx2 = S*ifft(tx2);
    td_tx3 = S*ifft(tx3);
    td_tx4 = S*ifft(tx4);

    % Make sure that we aren't overflowing past the limit.

    tx1_I = 1*int16(real(td_tx1));
    tx1_Q = 1*int16(imag(td_tx1));
    tx2_I = 1*int16(real(td_tx2));
    tx2_Q = 1*int16(imag(td_tx2));
    tx3_I = 1*int16(real(td_tx3));
    tx3_Q = 1*int16(imag(td_tx3));
    tx4_I = 1*int16(real(td_tx4));
    tx4_Q = 1*int16(imag(td_tx4));
    
    figure(1);
    plot(tx1_I);
     
    blob = [tx1_I; tx1_Q; tx2_I; tx2_Q; tx3_I; tx3_Q; tx4_I; tx4_Q];
end 