% Author: Aditya Dhananjay

classdef sdr
    
    properties
        data_client
        ctrl_client
        piradio_client
    end    
    
    methods
        
        function obj = zcu111_open_sockets(obj, ip_addr)
            obj.data_client = tcpip(ip_addr, 8082, 'NetworkRole', 'Client', 'Timeout', 5);
            obj.data_client.OutputBufferSize = 16384;
            obj.data_client.InputBufferSize = 32768*2;
            fopen(obj.data_client);
            
            obj.ctrl_client = tcpip(ip_addr, 8081, 'NetworkRole', 'Client', 'Timeout', 5);
            fopen(obj.ctrl_client);
            
            obj.piradio_client = tcpip(ip_addr, 8083, 'NetworkRole', 'Client', 'Timeout', 5);
            fopen(obj.piradio_client);
            
        end
        
        function obj = zcu111_close(obj)
            zcu111_ctrl_send_command_check_response(obj, 'disconnect', 'disconnect');
            pause(0.2);
            fclose(obj.ctrl_client);
            fclose(obj.data_client);
            
            fwrite(obj.piradio_client, 'disconnect');
            pause(0.1);
            fclose(obj.piradio_client);
        end
        
        function zcu111_data_send_command(obj, command)
            s = sprintf('%s%c%c', command, char(13), newline);
            fprintf('Sending data command: %s', s);
            fwrite(obj.data_client, s);
        end
        
        function zcu111_data_send_blob(obj, blob)
            fprintf('Start: Writing data blob of size %d samples\n', length(blob));
            fwrite(obj.data_client, swapbytes(blob), 'int16');
            fprintf('Finish: Writing data blob of size %d samples\n', length(blob));
            pause(0.2);
        end
        
        function zcu111_data_check_response(obj, expected_response)
            for i=1:5
                st = fscanf(obj.data_client);
                if (strlength(st) > 2)
                    break;
                end
            end
            
            if (strlength(st) >= strlength(expected_response))
                % Sometimes, we receive weird spaces. We need to cut those out.
                st = st(1:strlength(expected_response));
            end
            
            if (strcmp(st, expected_response) == 0)
                fprintf('ERROR: Data Channel: Did not match!\n');
                fprintf('  Expected: %s of length %d\n', ...
                    expected_response, strlength(expected_response));
                fprintf('  Got:      %s of length %d\n', ...
                    st, strlength(st));
            else
                fprintf('Matched! Expected: %s Got: %s\n', expected_response, st);
            end
        end
        
        function blob = rx_path_remove_zeros(obj, input_blob)
            blob = zeros(0);
            for i=1:1024
                a = input_blob( (i-1)*16 + 1   :   (i-1)*16 + 8);
                blob = [blob; a];
            end
        end
        
        function [obj, rx_blob] = zcu111_rd_data_blob(obj)
            
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 0 0 0 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 0 0 1 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 0 1 0 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 0 1 1 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 0 2 0 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 0 2 1 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 0 3 0 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 0 3 1 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'LocalMemInfo 0', 'LocalMemInfo 0 04E33880 4 16 131072 16 0 0');
            zcu111_ctrl_send_command_check_response(obj, 'LocalMemTrigger 0 4 8192 0x00FF', 'LocalMemTrigger');
            
            zcu111_data_send_command(obj, 'ReadDataFromMemory 0 0 32768 1');
            ch0_I = fread(obj.data_client, 16384, 'int16');
            ch0_I = rx_path_remove_zeros(obj, ch0_I);
            ch0_I = int16(ch0_I);
            ch0_I = swapbytes(ch0_I);
            zcu111_data_check_response(obj, 'ReadDataFromMemory');
            
            zcu111_data_send_command(obj, 'ReadDataFromMemory 0 1 32768 1');
            ch0_Q = fread(obj.data_client, 16384, 'int16');
            ch0_Q = rx_path_remove_zeros(obj, ch0_Q);
            ch0_Q = int16(ch0_Q);
            ch0_Q = swapbytes(ch0_Q);
            zcu111_data_check_response(obj, 'ReadDataFromMemory');
            
            zcu111_data_send_command(obj, 'ReadDataFromMemory 1 0 32768 1');
            ch1_I = fread(obj.data_client, 16384, 'int16');
            ch1_I = rx_path_remove_zeros(obj, ch1_I);
            ch1_I = int16(ch1_I);
            ch1_I = swapbytes(ch1_I);
            zcu111_data_check_response(obj, 'ReadDataFromMemory');
            
            zcu111_data_send_command(obj, 'ReadDataFromMemory 1 1 32768 1');
            ch1_Q = fread(obj.data_client, 16384, 'int16');
            ch1_Q = rx_path_remove_zeros(obj, ch1_Q);
            ch1_Q = int16(ch1_Q);
            ch1_Q = swapbytes(ch1_Q);
            zcu111_data_check_response(obj, 'ReadDataFromMemory');
            
            zcu111_data_send_command(obj, 'ReadDataFromMemory 2 1 32768 1');
            ch2_I = fread(obj.data_client, 16384, 'int16');
            ch2_I = rx_path_remove_zeros(obj, ch2_I);
            ch2_I = int16(ch2_I);
            ch2_I = swapbytes(ch2_I);
            zcu111_data_check_response(obj, 'ReadDataFromMemory');
            
            zcu111_data_send_command(obj, 'ReadDataFromMemory 3 1 32768 1');
            ch2_Q = fread(obj.data_client, 16384, 'int16');
            ch2_Q = rx_path_remove_zeros(obj, ch2_Q);
            ch2_Q = int16(ch2_Q);
            ch2_Q = swapbytes(ch2_Q);
            zcu111_data_check_response(obj, 'ReadDataFromMemory');
            
            zcu111_data_send_command(obj, 'ReadDataFromMemory 2 0 32768 1');
            ch3_I = fread(obj.data_client, 16384, 'int16');
            ch3_I = rx_path_remove_zeros(obj, ch3_I);
            ch3_I = int16(ch3_I);
            ch3_I = swapbytes(ch3_I);
            zcu111_data_check_response(obj, 'ReadDataFromMemory');
            
            zcu111_data_send_command(obj, 'ReadDataFromMemory 3 0 32768 1');
            ch3_Q = fread(obj.data_client, 16384, 'int16');
            ch3_Q = rx_path_remove_zeros(obj, ch3_Q);
            ch3_Q = int16(ch3_Q);
            ch3_Q = swapbytes(ch3_Q);
            zcu111_data_check_response(obj, 'ReadDataFromMemory');
                        
            rx_blob = [ch0_I'; ch0_Q'; ch1_Q'; ch1_I'; ch2_I'; ch2_Q'; ch3_I'; ch3_Q'];          
        end
       
        function obj = zcu111_wr_data_blob(obj, big_blob)
            zcu111_ctrl_send_command_check_response(obj, 'LocalMemInfo 1', 'LocalMemInfo 1 05204180 2 16 131072 16 0 1');
            zcu111_ctrl_send_command_check_response(obj, 'LocalMemTrigger 1 0 0 0x0000', 'LocalMemTrigger');
            
            zcu111_data_send_command(obj,  'WriteDataToMemory 0 0 16384 0');
            zcu111_data_send_blob(obj, big_blob(1,:));
            zcu111_data_check_response(obj, 'WriteDataToMemory');
            
            zcu111_data_send_command(obj,  'WriteDataToMemory 0 1 16384 0');
            zcu111_data_send_blob(obj, big_blob(2,:));
            zcu111_data_check_response(obj, 'WriteDataToMemory');
            
            zcu111_data_send_command(obj,  'WriteDataToMemory 0 2 16384 0');
            zcu111_data_send_blob(obj, big_blob(3,:));
            zcu111_data_check_response(obj, 'WriteDataToMemory');
            
            zcu111_data_send_command(obj,  'WriteDataToMemory 0 3 16384 0');
            zcu111_data_send_blob(obj, big_blob(4,:));
            zcu111_data_check_response(obj, 'WriteDataToMemory');
            
            zcu111_data_send_command(obj,  'WriteDataToMemory 1 0 16384 0');
            zcu111_data_send_blob(obj, big_blob(5,:));
            zcu111_data_check_response(obj, 'WriteDataToMemory');
             
            zcu111_data_send_command(obj,  'WriteDataToMemory 1 1 16384 0');
            zcu111_data_send_blob(obj, big_blob(6,:));
            zcu111_data_check_response(obj, 'WriteDataToMemory');
            
            zcu111_data_send_command(obj,  'WriteDataToMemory 1 2 16384 0');
            zcu111_data_send_blob(obj, big_blob(7,:));
            zcu111_data_check_response(obj, 'WriteDataToMemory');
            
            zcu111_data_send_command(obj,  'WriteDataToMemory 1 3 16384 0');
            zcu111_data_send_blob(obj, big_blob(8,:));
            zcu111_data_check_response(obj, 'WriteDataToMemory');
            
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 1 0 0 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 1 0 1 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 1 0 2 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 1 0 3 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 1 1 0 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 1 1 1 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 1 1 2 8192', 'SetLocalMemSample');
            zcu111_ctrl_send_command_check_response(obj, 'SetLocalMemSample 1 1 3 8192', 'SetLocalMemSample');
            
            zcu111_ctrl_send_command_check_response(obj, 'LocalMemTrigger 1 2 0 0x00FF', 'LocalMemTrigger');
            zcu111_ctrl_send_command_check_response(obj, 'LocalMemInfo 1', 'LocalMemInfo 1 05204180 2 16 131072 16 255 1');

        end
       
        function zcu111_ctrl_send_command_check_response(obj, command, expected_response)          
            s = sprintf('%s%c%c', command, char(13), newline);
            fwrite(obj.ctrl_client, s);
            for i=1:5
                st = fscanf(obj.ctrl_client);
                if (strlength(st) > 2)
                    break;
                end
            end
            if (strlength(st) >= strlength(expected_response))
                % Sometimes, we receive weird spaces. We need to cut those out.
                st = st(1:strlength(expected_response));
            end
            
            if (strcmp(expected_response(1:5), 'ERROR') == 1)
                % This is an error condition. Just make sure we get an error
                st = 'ERROR'; % This is to ignore the error
                expected_response = expected_response(1:5);
                % Throw away the next line (errors come in over two lines
            end
            
            if (strcmp(st, expected_response) == 0)
                fprintf('ERROR: Did not match for command %s\n', command);
                fprintf('  Expected: %s of length %d\n', ...
                    expected_response, strlength(expected_response));
                fprintf('  Got:      %s of length %d\n', ...
                    st, strlength(st));
            else
                fprintf('Matched! Issued: %s Expected: %s Got: %s\n', ...
                    command, expected_response, st);
            end
        end
        
        function obj = zcu111_open(obj, ip_addr)
            
            obj = zcu111_open_sockets(obj, ip_addr);
            zcu111_ctrl_send_command_check_response(obj, 'TermMode 1', 'TermMode');
            
            % Over here, issue all the commands that you want
            filestr = fileread('commands.txt');
            filebyline = regexp(filestr, '\n', 'split');
            filebyline( cellfun(@isempty,filebyline) ) = [];
            filebyfield = regexp(filebyline, '\t', 'split');
            
            for i=1:numel(filebyfield)
                
                a = filebyfield(i);
                b = a{1}{1};
                if (strcmp(b(1:1), '%') == 1)
                    % Ignore the comment line in the commands file
                else
                    fprintf('Initial configuration: Line %d: ', i);
                    zcu111_ctrl_send_command_check_response(obj, a{1}{1}, a{1}{2});
                end
            end
            
        end              
        
    end
end